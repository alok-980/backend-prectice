import jwt from 'jsonwebtoken'
import userModel from '../model/user.model';

export async function requireAuth(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: 'Not logged in' });

  try {
    const { id } = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await userModel.findById(id);
    if (!req.user) return res.status(401).json({ message: 'User not found' });
    next();
  } catch {
    res.status(401).json({ message: 'Invalid or expired token' });
  }
}

// Session version is one line: if (req.isAuthenticated()) return next();
